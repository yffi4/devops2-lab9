{{- define "api.name" -}}
{{- .Release.Name }}-api
{{- end }}

{{- define "api.serviceName" -}}
{{- .Release.Name }}-api-service
{{- end }}

{{- define "api.selectorLabels" -}}
app: {{ include "api.name" . }}
{{- end }}

{{- define "api.labels" -}}
{{ include "api.selectorLabels" . }}
app.kubernetes.io/component: api
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
