{{- define "postgres.name" -}}
{{- .Release.Name }}-postgres
{{- end }}

{{- define "postgres.serviceName" -}}
{{- .Release.Name }}-postgres-service
{{- end }}

{{- define "postgres.selectorLabels" -}}
app: {{ include "postgres.name" . }}
{{- end }}

{{- define "postgres.labels" -}}
{{ include "postgres.selectorLabels" . }}
app.kubernetes.io/component: database
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
